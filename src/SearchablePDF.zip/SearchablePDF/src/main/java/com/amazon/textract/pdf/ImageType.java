package com.amazon.textract.pdf;

public enum ImageType {
    JPEG, PNG;
}
